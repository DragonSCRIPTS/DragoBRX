# brx/utils.py
def log(message):
    print(f"[BRX LOG] {message}")

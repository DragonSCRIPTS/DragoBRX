# brx/config.py
CONFIG = {
    "name": "BRX",
    "version": "2.0",
    "model_type": "online",
    "training_data_path": "training/",
    "output_format": "lua",
    "roblox_services": ["ReplicatedStorage", "Players", "TweenService"]
}

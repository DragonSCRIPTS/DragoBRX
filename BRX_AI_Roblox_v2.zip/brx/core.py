# brx/core.py
class BRXCore:
    def __init__(self, config):
        self.config = config

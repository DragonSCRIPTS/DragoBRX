#!/usr/bin/env python3
# main.py
# Projeto: BRX - IA Geradora de Scripts Roblox
# Desenvolvido por DragonSCP

import argparse
from brx.generator import ScriptGenerator
from brx.config import CONFIG

def main():
    parser = argparse.ArgumentParser(description="BRX - Gerador de Scripts Roblox")
    parser.add_argument("task", choices=["generate", "train"], help="Tarefa para a IA: gerar código ou treinar modelo")
    parser.add_argument("--prompt", "-p", type=str, help="Descrição para geração de script")
    args = parser.parse_args()

    generator = ScriptGenerator(CONFIG)
    if args.task == "generate":
        if not args.prompt:
            print("Erro: forneça --prompt para gerar código.")
            return
        result = generator.generate_script(args.prompt)
        print(result)
    elif args.task == "train":
        from brx.trainer import Trainer
        trainer = Trainer(CONFIG)
        trainer.train()
        print("Treinamento concluído.")

if __name__ == "__main__":
    main()

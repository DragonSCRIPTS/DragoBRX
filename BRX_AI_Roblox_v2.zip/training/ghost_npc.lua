-- Exemplo de script de NPC fantasma
local ReplicatedStorage = game:GetService("ReplicatedStorage")
-- ... (demais funções retiradas para exemplo de treino)

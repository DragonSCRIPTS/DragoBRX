# BRX - IA Geradora de Scripts Roblox

BRX é uma inteligência artificial que gera códigos otimizados para Roblox Studio em formato Lua, sem limite de tamanho.

## Estrutura do Projeto

- `main.py` - Ponto de entrada (CLI).
- `brx/`
  - `generator.py` - Geração de scripts a partir de prompts.
  - `trainer.py` - Pré-treinamento usando exemplos em `training/`.
  - `config.py` - Configurações gerais.
  - `utils.py` - Funções utilitárias.
- `training/` - Exemplos de scripts para treinamento.

## Uso

### Gerar script
```bash
python main.py generate -p "Criar um NPC que segue o jogador"
```

### Treinar modelo
```bash
python main.py train
```
